<?php
$dalTablegroup_operation_off = array();
$dalTablegroup_operation_off["operation_id"] = array("type"=>20,"varname"=>"operation_id", "name" => "operation_id");
$dalTablegroup_operation_off["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
$dalTablegroup_operation_off["day_off"] = array("type"=>7,"varname"=>"day_off", "name" => "day_off");
$dalTablegroup_operation_off["desc"] = array("type"=>200,"varname"=>"desc", "name" => "desc");
	$dalTablegroup_operation_off["operation_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_operation_off"] = &$dalTablegroup_operation_off;
?>