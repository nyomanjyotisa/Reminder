<?php
$dalTableproject5_ugmembers = array();
$dalTableproject5_ugmembers["UserName"] = array("type"=>200,"varname"=>"UserName", "name" => "UserName");
$dalTableproject5_ugmembers["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID");
	$dalTableproject5_ugmembers["UserName"]["key"]=true;
	$dalTableproject5_ugmembers["GroupID"]["key"]=true;

$dal_info["notif_basic1_at_localhost__project5_ugmembers"] = &$dalTableproject5_ugmembers;
?>