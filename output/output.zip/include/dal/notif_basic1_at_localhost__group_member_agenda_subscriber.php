<?php
$dalTablegroup_member_agenda_subscriber = array();
$dalTablegroup_member_agenda_subscriber["group_member_id"] = array("type"=>20,"varname"=>"group_member_id", "name" => "group_member_id");
$dalTablegroup_member_agenda_subscriber["member_id"] = array("type"=>20,"varname"=>"member_id", "name" => "member_id");
$dalTablegroup_member_agenda_subscriber["agenda_type_id"] = array("type"=>20,"varname"=>"agenda_type_id", "name" => "agenda_type_id");
$dalTablegroup_member_agenda_subscriber["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
	$dalTablegroup_member_agenda_subscriber["group_member_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_member_agenda_subscriber"] = &$dalTablegroup_member_agenda_subscriber;
?>