<?php
$dalTableproduct_type = array();
$dalTableproduct_type["id_product_type"] = array("type"=>16,"varname"=>"id_product_type", "name" => "id_product_type");
$dalTableproduct_type["product_type"] = array("type"=>200,"varname"=>"product_type", "name" => "product_type");
	$dalTableproduct_type["id_product_type"]["key"]=true;

$dal_info["notif_basic1_at_localhost__product_type"] = &$dalTableproduct_type;
?>