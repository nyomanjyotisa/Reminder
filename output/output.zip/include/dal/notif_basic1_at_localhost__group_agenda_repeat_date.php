<?php
$dalTablegroup_agenda_repeat_date = array();
$dalTablegroup_agenda_repeat_date["id_group_repeat"] = array("type"=>20,"varname"=>"id_group_repeat", "name" => "id_group_repeat");
$dalTablegroup_agenda_repeat_date["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
$dalTablegroup_agenda_repeat_date["group_agenda_id"] = array("type"=>20,"varname"=>"group_agenda_id", "name" => "group_agenda_id");
$dalTablegroup_agenda_repeat_date["dodate"] = array("type"=>135,"varname"=>"dodate", "name" => "dodate");
	$dalTablegroup_agenda_repeat_date["id_group_repeat"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_agenda_repeat_date"] = &$dalTablegroup_agenda_repeat_date;
?>