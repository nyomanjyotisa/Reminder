<?php
$dalTablepersonal_agenda_repeat_date = array();
$dalTablepersonal_agenda_repeat_date["id_group_repeat"] = array("type"=>20,"varname"=>"id_group_repeat", "name" => "id_group_repeat");
$dalTablepersonal_agenda_repeat_date["member_agenda_id"] = array("type"=>20,"varname"=>"member_agenda_id", "name" => "member_agenda_id");
$dalTablepersonal_agenda_repeat_date["dodate"] = array("type"=>135,"varname"=>"dodate", "name" => "dodate");
	$dalTablepersonal_agenda_repeat_date["id_group_repeat"]["key"]=true;

$dal_info["notif_basic1_at_localhost__personal_agenda_repeat_date"] = &$dalTablepersonal_agenda_repeat_date;
?>