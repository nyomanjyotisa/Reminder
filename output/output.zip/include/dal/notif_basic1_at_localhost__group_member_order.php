<?php
$dalTablegroup_member_order = array();
$dalTablegroup_member_order["group_member_order"] = array("type"=>20,"varname"=>"group_member_order", "name" => "group_member_order");
$dalTablegroup_member_order["group_member_id"] = array("type"=>20,"varname"=>"group_member_id", "name" => "group_member_id");
$dalTablegroup_member_order["member_id"] = array("type"=>20,"varname"=>"member_id", "name" => "member_id");
$dalTablegroup_member_order["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
$dalTablegroup_member_order["order_date"] = array("type"=>135,"varname"=>"order_date", "name" => "order_date");
$dalTablegroup_member_order["valid"] = array("type"=>129,"varname"=>"valid", "name" => "valid");
$dalTablegroup_member_order["total"] = array("type"=>5,"varname"=>"total", "name" => "total");
$dalTablegroup_member_order["currency"] = array("type"=>200,"varname"=>"currency", "name" => "currency");
$dalTablegroup_member_order["review_member"] = array("type"=>201,"varname"=>"review_member", "name" => "review_member");
$dalTablegroup_member_order["rating_member"] = array("type"=>16,"varname"=>"rating_member", "name" => "rating_member");
$dalTablegroup_member_order["payment_status"] = array("type"=>129,"varname"=>"payment_status", "name" => "payment_status");
$dalTablegroup_member_order["money_received"] = array("type"=>5,"varname"=>"money_received", "name" => "money_received");
$dalTablegroup_member_order["change_money"] = array("type"=>5,"varname"=>"change_money", "name" => "change_money");
	$dalTablegroup_member_order["group_member_order"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_member_order"] = &$dalTablegroup_member_order;
?>