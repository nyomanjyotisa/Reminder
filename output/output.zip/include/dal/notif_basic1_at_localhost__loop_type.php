<?php
$dalTableloop_type = array();
$dalTableloop_type["id_loop"] = array("type"=>3,"varname"=>"id_loop", "name" => "id_loop");
$dalTableloop_type["loop_type"] = array("type"=>200,"varname"=>"loop_type", "name" => "loop_type");
$dalTableloop_type["desc"] = array("type"=>200,"varname"=>"desc", "name" => "desc");
	$dalTableloop_type["id_loop"]["key"]=true;

$dal_info["notif_basic1_at_localhost__loop_type"] = &$dalTableloop_type;
?>