<?php
$dalTablelookup_stok = array();
$dalTablelookup_stok["lookup_stok_id"] = array("type"=>20,"varname"=>"lookup_stok_id", "name" => "lookup_stok_id");
$dalTablelookup_stok["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
$dalTablelookup_stok["product_name"] = array("type"=>200,"varname"=>"product_name", "name" => "product_name");
$dalTablelookup_stok["stock"] = array("type"=>3,"varname"=>"stock", "name" => "stock");
	$dalTablelookup_stok["lookup_stok_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__lookup_stok"] = &$dalTablelookup_stok;
?>