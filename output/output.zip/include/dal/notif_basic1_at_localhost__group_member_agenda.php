<?php
$dalTablegroup_member_agenda = array();
$dalTablegroup_member_agenda["group_member_agenda_id"] = array("type"=>20,"varname"=>"group_member_agenda_id", "name" => "group_member_agenda_id");
$dalTablegroup_member_agenda["group_member_id"] = array("type"=>20,"varname"=>"group_member_id", "name" => "group_member_id");
$dalTablegroup_member_agenda["member_id"] = array("type"=>20,"varname"=>"member_id", "name" => "member_id");
$dalTablegroup_member_agenda["group_agenda_id"] = array("type"=>20,"varname"=>"group_agenda_id", "name" => "group_agenda_id");
$dalTablegroup_member_agenda["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
	$dalTablegroup_member_agenda["group_member_agenda_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_member_agenda"] = &$dalTablegroup_member_agenda;
?>