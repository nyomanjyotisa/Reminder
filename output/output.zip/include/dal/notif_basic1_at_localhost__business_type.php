<?php
$dalTablebusiness_type = array();
$dalTablebusiness_type["business_type_id"] = array("type"=>16,"varname"=>"business_type_id", "name" => "business_type_id");
$dalTablebusiness_type["business_type"] = array("type"=>200,"varname"=>"business_type", "name" => "business_type");
	$dalTablebusiness_type["business_type_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__business_type"] = &$dalTablebusiness_type;
?>