<?php
$dalTablegroup_user_type = array();
$dalTablegroup_user_type["id_user_type"] = array("type"=>16,"varname"=>"id_user_type", "name" => "id_user_type");
$dalTablegroup_user_type["user_type"] = array("type"=>200,"varname"=>"user_type", "name" => "user_type");
	$dalTablegroup_user_type["id_user_type"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_user_type"] = &$dalTablegroup_user_type;
?>