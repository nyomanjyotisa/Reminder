<?php
$dalTablechannel = array();
$dalTablechannel["channel_id"] = array("type"=>16,"varname"=>"channel_id", "name" => "channel_id");
$dalTablechannel["channel_name"] = array("type"=>200,"varname"=>"channel_name", "name" => "channel_name");
	$dalTablechannel["channel_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__channel"] = &$dalTablechannel;
?>