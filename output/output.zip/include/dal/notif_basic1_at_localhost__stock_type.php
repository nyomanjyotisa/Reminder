<?php
$dalTablestock_type = array();
$dalTablestock_type["stock_type_id"] = array("type"=>16,"varname"=>"stock_type_id", "name" => "stock_type_id");
$dalTablestock_type["stock_type"] = array("type"=>200,"varname"=>"stock_type", "name" => "stock_type");
	$dalTablestock_type["stock_type_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__stock_type"] = &$dalTablestock_type;
?>