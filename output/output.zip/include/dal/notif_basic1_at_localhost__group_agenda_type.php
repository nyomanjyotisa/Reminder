<?php
$dalTablegroup_agenda_type = array();
$dalTablegroup_agenda_type["agenda_type_id"] = array("type"=>20,"varname"=>"agenda_type_id", "name" => "agenda_type_id");
$dalTablegroup_agenda_type["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
$dalTablegroup_agenda_type["agenda_type"] = array("type"=>200,"varname"=>"agenda_type", "name" => "agenda_type");
$dalTablegroup_agenda_type["description"] = array("type"=>200,"varname"=>"description", "name" => "description");
$dalTablegroup_agenda_type["group_requested"] = array("type"=>20,"varname"=>"group_requested", "name" => "group_requested");
$dalTablegroup_agenda_type["valid"] = array("type"=>16,"varname"=>"valid", "name" => "valid");
	$dalTablegroup_agenda_type["agenda_type_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_agenda_type"] = &$dalTablegroup_agenda_type;
?>