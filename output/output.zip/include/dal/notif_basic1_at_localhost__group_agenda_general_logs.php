<?php
$dalTablegroup_agenda_general_logs = array();
$dalTablegroup_agenda_general_logs["id_logs"] = array("type"=>3,"varname"=>"id_logs", "name" => "id_logs");
$dalTablegroup_agenda_general_logs["member_id"] = array("type"=>20,"varname"=>"member_id", "name" => "member_id");
$dalTablegroup_agenda_general_logs["id_group_agenda"] = array("type"=>20,"varname"=>"id_group_agenda", "name" => "id_group_agenda");
$dalTablegroup_agenda_general_logs["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
$dalTablegroup_agenda_general_logs["date_send"] = array("type"=>135,"varname"=>"date_send", "name" => "date_send");
	$dalTablegroup_agenda_general_logs["id_logs"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_agenda_general_logs"] = &$dalTablegroup_agenda_general_logs;
?>