<?php
$dalTablelookup_token = array();
$dalTablelookup_token["id_lookup"] = array("type"=>20,"varname"=>"id_lookup", "name" => "id_lookup");
$dalTablelookup_token["id_group"] = array("type"=>20,"varname"=>"id_group", "name" => "id_group");
$dalTablelookup_token["group_identifier"] = array("type"=>200,"varname"=>"group_identifier", "name" => "group_identifier");
$dalTablelookup_token["token"] = array("type"=>200,"varname"=>"token", "name" => "token");
	$dalTablelookup_token["id_lookup"]["key"]=true;

$dal_info["notif_basic1_at_localhost__lookup_token"] = &$dalTablelookup_token;
?>