<?php
$dalTablepersonal_agenda = array();
$dalTablepersonal_agenda["member_agenda_id"] = array("type"=>20,"varname"=>"member_agenda_id", "name" => "member_agenda_id");
$dalTablepersonal_agenda["member_id"] = array("type"=>20,"varname"=>"member_id", "name" => "member_id");
$dalTablepersonal_agenda["loop_type"] = array("type"=>3,"varname"=>"loop_type", "name" => "loop_type");
$dalTablepersonal_agenda["loop_value"] = array("type"=>135,"varname"=>"loop_value", "name" => "loop_value");
$dalTablepersonal_agenda["message_content"] = array("type"=>200,"varname"=>"message_content", "name" => "message_content");
$dalTablepersonal_agenda["attachment"] = array("type"=>200,"varname"=>"attachment", "name" => "attachment");
$dalTablepersonal_agenda["repeat"] = array("type"=>3,"varname"=>"repeat", "name" => "repeat");
$dalTablepersonal_agenda["repeat_type"] = array("type"=>129,"varname"=>"repeat_type", "name" => "repeat_type");
	$dalTablepersonal_agenda["member_agenda_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__personal_agenda"] = &$dalTablepersonal_agenda;
?>