<?php
$dalTableproject5_uggroups = array();
$dalTableproject5_uggroups["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID");
$dalTableproject5_uggroups["Label"] = array("type"=>200,"varname"=>"Label", "name" => "Label");
	$dalTableproject5_uggroups["GroupID"]["key"]=true;

$dal_info["notif_basic1_at_localhost__project5_uggroups"] = &$dalTableproject5_uggroups;
?>