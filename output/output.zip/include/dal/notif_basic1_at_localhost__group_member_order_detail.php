<?php
$dalTablegroup_member_order_detail = array();
$dalTablegroup_member_order_detail["group_member_order_detail_id"] = array("type"=>20,"varname"=>"group_member_order_detail_id", "name" => "group_member_order_detail_id");
$dalTablegroup_member_order_detail["group_member_order_id"] = array("type"=>20,"varname"=>"group_member_order_id", "name" => "group_member_order_id");
$dalTablegroup_member_order_detail["group_member_id"] = array("type"=>20,"varname"=>"group_member_id", "name" => "group_member_id");
$dalTablegroup_member_order_detail["member_id"] = array("type"=>20,"varname"=>"member_id", "name" => "member_id");
$dalTablegroup_member_order_detail["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
$dalTablegroup_member_order_detail["group_product_id"] = array("type"=>20,"varname"=>"group_product_id", "name" => "group_product_id");
$dalTablegroup_member_order_detail["nominal"] = array("type"=>5,"varname"=>"nominal", "name" => "nominal");
$dalTablegroup_member_order_detail["quantity"] = array("type"=>16,"varname"=>"quantity", "name" => "quantity");
$dalTablegroup_member_order_detail["total"] = array("type"=>5,"varname"=>"total", "name" => "total");
$dalTablegroup_member_order_detail["progress"] = array("type"=>129,"varname"=>"progress", "name" => "progress");
	$dalTablegroup_member_order_detail["group_member_order_detail_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_member_order_detail"] = &$dalTablegroup_member_order_detail;
?>