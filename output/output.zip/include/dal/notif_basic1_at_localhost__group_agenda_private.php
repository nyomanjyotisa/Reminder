<?php
$dalTablegroup_agenda_private = array();
$dalTablegroup_agenda_private["group_agenda_private_id"] = array("type"=>20,"varname"=>"group_agenda_private_id", "name" => "group_agenda_private_id");
$dalTablegroup_agenda_private["id_group_agenda"] = array("type"=>20,"varname"=>"id_group_agenda", "name" => "id_group_agenda");
$dalTablegroup_agenda_private["id_member"] = array("type"=>20,"varname"=>"id_member", "name" => "id_member");
$dalTablegroup_agenda_private["group_id"] = array("type"=>20,"varname"=>"group_id", "name" => "group_id");
$dalTablegroup_agenda_private["message_content"] = array("type"=>201,"varname"=>"message_content", "name" => "message_content");
$dalTablegroup_agenda_private["attachment"] = array("type"=>200,"varname"=>"attachment", "name" => "attachment");
$dalTablegroup_agenda_private["date_send"] = array("type"=>135,"varname"=>"date_send", "name" => "date_send");
	$dalTablegroup_agenda_private["group_agenda_private_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__group_agenda_private"] = &$dalTablegroup_agenda_private;
?>