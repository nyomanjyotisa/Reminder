<?php
$dalTableproject5_ugrights = array();
$dalTableproject5_ugrights["TableName"] = array("type"=>200,"varname"=>"TableName", "name" => "TableName");
$dalTableproject5_ugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID");
$dalTableproject5_ugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask", "name" => "AccessMask");
$dalTableproject5_ugrights["Page"] = array("type"=>201,"varname"=>"Page", "name" => "Page");
	$dalTableproject5_ugrights["TableName"]["key"]=true;
	$dalTableproject5_ugrights["GroupID"]["key"]=true;

$dal_info["notif_basic1_at_localhost__project5_ugrights"] = &$dalTableproject5_ugrights;
?>