<?php
$dalTablemembership_type = array();
$dalTablemembership_type["membership_id"] = array("type"=>16,"varname"=>"membership_id", "name" => "membership_id");
$dalTablemembership_type["membership_type"] = array("type"=>200,"varname"=>"membership_type", "name" => "membership_type");
	$dalTablemembership_type["membership_id"]["key"]=true;

$dal_info["notif_basic1_at_localhost__membership_type"] = &$dalTablemembership_type;
?>