<?php
$tdatagroup_member_order = array();
$tdatagroup_member_order[".searchableFields"] = array();
$tdatagroup_member_order[".ShortName"] = "group_member_order";
$tdatagroup_member_order[".OwnerID"] = "member_id";
$tdatagroup_member_order[".OriginalTable"] = "group_member_order";


$tdatagroup_member_order[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"masterlist\":[\"masterlist\"],\"masterprint\":[\"masterprint\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdatagroup_member_order[".originalPagesByType"] = $tdatagroup_member_order[".pagesByType"];
$tdatagroup_member_order[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"masterlist\":[\"masterlist\"],\"masterprint\":[\"masterprint\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdatagroup_member_order[".originalPages"] = $tdatagroup_member_order[".pages"];
$tdatagroup_member_order[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"masterlist\":\"masterlist\",\"masterprint\":\"masterprint\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdatagroup_member_order[".originalDefaultPages"] = $tdatagroup_member_order[".defaultPages"];

//	field labels
$fieldLabelsgroup_member_order = array();
$fieldToolTipsgroup_member_order = array();
$pageTitlesgroup_member_order = array();
$placeHoldersgroup_member_order = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsgroup_member_order["English"] = array();
	$fieldToolTipsgroup_member_order["English"] = array();
	$placeHoldersgroup_member_order["English"] = array();
	$pageTitlesgroup_member_order["English"] = array();
	$fieldLabelsgroup_member_order["English"]["group_member_order"] = "Order Id";
	$fieldToolTipsgroup_member_order["English"]["group_member_order"] = "";
	$placeHoldersgroup_member_order["English"]["group_member_order"] = "";
	$fieldLabelsgroup_member_order["English"]["group_member_id"] = "Group Member Id";
	$fieldToolTipsgroup_member_order["English"]["group_member_id"] = "";
	$placeHoldersgroup_member_order["English"]["group_member_id"] = "";
	$fieldLabelsgroup_member_order["English"]["member_id"] = "Member Name";
	$fieldToolTipsgroup_member_order["English"]["member_id"] = "";
	$placeHoldersgroup_member_order["English"]["member_id"] = "";
	$fieldLabelsgroup_member_order["English"]["group_id"] = "Group Name";
	$fieldToolTipsgroup_member_order["English"]["group_id"] = "";
	$placeHoldersgroup_member_order["English"]["group_id"] = "";
	$fieldLabelsgroup_member_order["English"]["order_date"] = "Order Date";
	$fieldToolTipsgroup_member_order["English"]["order_date"] = "";
	$placeHoldersgroup_member_order["English"]["order_date"] = "";
	$fieldLabelsgroup_member_order["English"]["valid"] = "Valid";
	$fieldToolTipsgroup_member_order["English"]["valid"] = "";
	$placeHoldersgroup_member_order["English"]["valid"] = "";
	$fieldLabelsgroup_member_order["English"]["total"] = "Total";
	$fieldToolTipsgroup_member_order["English"]["total"] = "";
	$placeHoldersgroup_member_order["English"]["total"] = "";
	$fieldLabelsgroup_member_order["English"]["currency"] = "Currency";
	$fieldToolTipsgroup_member_order["English"]["currency"] = "";
	$placeHoldersgroup_member_order["English"]["currency"] = "";
	$fieldLabelsgroup_member_order["English"]["review_member"] = "Review Member";
	$fieldToolTipsgroup_member_order["English"]["review_member"] = "";
	$placeHoldersgroup_member_order["English"]["review_member"] = "";
	$fieldLabelsgroup_member_order["English"]["rating_member"] = "Rating Member";
	$fieldToolTipsgroup_member_order["English"]["rating_member"] = "";
	$placeHoldersgroup_member_order["English"]["rating_member"] = "";
	$fieldLabelsgroup_member_order["English"]["payment_status"] = "Payment Status";
	$fieldToolTipsgroup_member_order["English"]["payment_status"] = "";
	$placeHoldersgroup_member_order["English"]["payment_status"] = "";
	$fieldLabelsgroup_member_order["English"]["money_received"] = "Money Received";
	$fieldToolTipsgroup_member_order["English"]["money_received"] = "";
	$placeHoldersgroup_member_order["English"]["money_received"] = "";
	$fieldLabelsgroup_member_order["English"]["change_money"] = "Change Money";
	$fieldToolTipsgroup_member_order["English"]["change_money"] = "";
	$placeHoldersgroup_member_order["English"]["change_money"] = "";
	if (count($fieldToolTipsgroup_member_order["English"]))
		$tdatagroup_member_order[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsgroup_member_order["Indonesian"] = array();
	$fieldToolTipsgroup_member_order["Indonesian"] = array();
	$placeHoldersgroup_member_order["Indonesian"] = array();
	$pageTitlesgroup_member_order["Indonesian"] = array();
	$fieldLabelsgroup_member_order["Indonesian"]["group_member_order"] = "Id Pesanan";
	$fieldToolTipsgroup_member_order["Indonesian"]["group_member_order"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["group_member_order"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["group_member_id"] = "Id Anggota Grup";
	$fieldToolTipsgroup_member_order["Indonesian"]["group_member_id"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["group_member_id"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["member_id"] = "Nama Anggota";
	$fieldToolTipsgroup_member_order["Indonesian"]["member_id"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["member_id"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["group_id"] = "Nama Group";
	$fieldToolTipsgroup_member_order["Indonesian"]["group_id"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["group_id"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["order_date"] = "Tanggal Pesanan";
	$fieldToolTipsgroup_member_order["Indonesian"]["order_date"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["order_date"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["valid"] = "Valid";
	$fieldToolTipsgroup_member_order["Indonesian"]["valid"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["valid"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["total"] = "Total";
	$fieldToolTipsgroup_member_order["Indonesian"]["total"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["total"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["currency"] = "Mata Uang";
	$fieldToolTipsgroup_member_order["Indonesian"]["currency"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["currency"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["review_member"] = "Ulasan Anggota";
	$fieldToolTipsgroup_member_order["Indonesian"]["review_member"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["review_member"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["rating_member"] = "Penilaian Anggota";
	$fieldToolTipsgroup_member_order["Indonesian"]["rating_member"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["rating_member"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["payment_status"] = "Status Pembayaran";
	$fieldToolTipsgroup_member_order["Indonesian"]["payment_status"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["payment_status"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["money_received"] = "Uang Diterima";
	$fieldToolTipsgroup_member_order["Indonesian"]["money_received"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["money_received"] = "";
	$fieldLabelsgroup_member_order["Indonesian"]["change_money"] = "Uang Kembalian";
	$fieldToolTipsgroup_member_order["Indonesian"]["change_money"] = "";
	$placeHoldersgroup_member_order["Indonesian"]["change_money"] = "";
	if (count($fieldToolTipsgroup_member_order["Indonesian"]))
		$tdatagroup_member_order[".isUseToolTips"] = true;
}


	$tdatagroup_member_order[".NCSearch"] = true;



$tdatagroup_member_order[".shortTableName"] = "group_member_order";
$tdatagroup_member_order[".nSecOptions"] = 2;

$tdatagroup_member_order[".mainTableOwnerID"] = "member_id";
$tdatagroup_member_order[".entityType"] = 0;
$tdatagroup_member_order[".connId"] = "notif_basic1_at_localhost";


$tdatagroup_member_order[".strOriginalTableName"] = "group_member_order";

	



$tdatagroup_member_order[".showAddInPopup"] = false;

$tdatagroup_member_order[".showEditInPopup"] = false;

$tdatagroup_member_order[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdatagroup_member_order[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdatagroup_member_order[".listAjax"] = false;
//	temporary
$tdatagroup_member_order[".listAjax"] = false;

	$tdatagroup_member_order[".audit"] = false;

	$tdatagroup_member_order[".locking"] = false;


$pages = $tdatagroup_member_order[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdatagroup_member_order[".edit"] = true;
	$tdatagroup_member_order[".afterEditAction"] = 0;
	$tdatagroup_member_order[".closePopupAfterEdit"] = 1;
	$tdatagroup_member_order[".afterEditActionDetTable"] = "group_member_order_detail";
}

if( $pages[PAGE_ADD] ) {
$tdatagroup_member_order[".add"] = true;
$tdatagroup_member_order[".afterAddAction"] = 0;
$tdatagroup_member_order[".closePopupAfterAdd"] = 1;
$tdatagroup_member_order[".afterAddActionDetTable"] = "group_member_order_detail";
}

if( $pages[PAGE_LIST] ) {
	$tdatagroup_member_order[".list"] = true;
}



$tdatagroup_member_order[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdatagroup_member_order[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdatagroup_member_order[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdatagroup_member_order[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdatagroup_member_order[".printFriendly"] = true;
}



$tdatagroup_member_order[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdatagroup_member_order[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdatagroup_member_order[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdatagroup_member_order[".isUseAjaxSuggest"] = true;

$tdatagroup_member_order[".rowHighlite"] = true;





$tdatagroup_member_order[".ajaxCodeSnippetAdded"] = false;

$tdatagroup_member_order[".buttonsAdded"] = false;

$tdatagroup_member_order[".addPageEvents"] = false;

// use timepicker for search panel
$tdatagroup_member_order[".isUseTimeForSearch"] = false;


$tdatagroup_member_order[".badgeColor"] = "CD853F";


$tdatagroup_member_order[".allSearchFields"] = array();
$tdatagroup_member_order[".filterFields"] = array();
$tdatagroup_member_order[".requiredSearchFields"] = array();

$tdatagroup_member_order[".googleLikeFields"] = array();
$tdatagroup_member_order[".googleLikeFields"][] = "group_member_order";
$tdatagroup_member_order[".googleLikeFields"][] = "group_member_id";
$tdatagroup_member_order[".googleLikeFields"][] = "member_id";
$tdatagroup_member_order[".googleLikeFields"][] = "group_id";
$tdatagroup_member_order[".googleLikeFields"][] = "order_date";
$tdatagroup_member_order[".googleLikeFields"][] = "valid";
$tdatagroup_member_order[".googleLikeFields"][] = "total";
$tdatagroup_member_order[".googleLikeFields"][] = "currency";
$tdatagroup_member_order[".googleLikeFields"][] = "review_member";
$tdatagroup_member_order[".googleLikeFields"][] = "rating_member";
$tdatagroup_member_order[".googleLikeFields"][] = "payment_status";
$tdatagroup_member_order[".googleLikeFields"][] = "money_received";
$tdatagroup_member_order[".googleLikeFields"][] = "change_money";



$tdatagroup_member_order[".tableType"] = "list";

$tdatagroup_member_order[".printerPageOrientation"] = 0;
$tdatagroup_member_order[".nPrinterPageScale"] = 100;

$tdatagroup_member_order[".nPrinterSplitRecords"] = 40;

$tdatagroup_member_order[".geocodingEnabled"] = false;










$tdatagroup_member_order[".pageSize"] = 20;

$tdatagroup_member_order[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdatagroup_member_order[".strOrderBy"] = $tstrOrderBy;

$tdatagroup_member_order[".orderindexes"] = array();


$tdatagroup_member_order[".sqlHead"] = "SELECT group_member_order,  	group_member_id,  	member_id,  	group_id,  	order_date,  	valid,  	total,  	currency,  	review_member,  	rating_member,  	payment_status,  	money_received,  	change_money";
$tdatagroup_member_order[".sqlFrom"] = "FROM group_member_order";
$tdatagroup_member_order[".sqlWhereExpr"] = "";
$tdatagroup_member_order[".sqlTail"] = "";

//fill array of tabs for list page
$arrGridTabs = array();
$arrGridTabs[] = array(
	'tabId' => "",
	'name' => "user",
	'nameType' => 'Text',
	'where' => "group_member_order.member_id = ':session.member_id'",
	'showRowCount' => 0,
	'hideEmpty' => 1,
);
$arrGridTabs[] = array(
	'tabId' => "1",
	'name' => "admin",
	'nameType' => 'Text',
	'where' => "group_id = ':session.group_id'",
	'showRowCount' => 0,
	'hideEmpty' => 1,
);
$tdatagroup_member_order[".arrGridTabs"] = $arrGridTabs;









//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatagroup_member_order[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatagroup_member_order[".arrGroupsPerPage"] = $arrGPP;

$tdatagroup_member_order[".highlightSearchResults"] = true;

$tableKeysgroup_member_order = array();
$tableKeysgroup_member_order[] = "group_member_order";
$tdatagroup_member_order[".Keys"] = $tableKeysgroup_member_order;


$tdatagroup_member_order[".hideMobileList"] = array();




//	group_member_order
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "group_member_order";
	$fdata["GoodName"] = "group_member_order";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","group_member_order");
	$fdata["FieldType"] = 20;

	
		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "group_member_order";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "group_member_order";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["group_member_order"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "group_member_order";
//	group_member_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "group_member_id";
	$fdata["GoodName"] = "group_member_id";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","group_member_id");
	$fdata["FieldType"] = 20;

	
	
	
			

		$fdata["strField"] = "group_member_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "group_member_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "group_member";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "group_member_id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "group_member_id";

	

	
	$edata["LookupOrderBy"] = "";

	
		$edata["UseCategory"] = true;
	$edata["categoryFields"] = array();
	$edata["categoryFields"][] = array( "main" => "member_id", "lookup" => "member_id" );

	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["group_member_id"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "group_member_id";
//	member_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "member_id";
	$fdata["GoodName"] = "member_id";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","member_id");
	$fdata["FieldType"] = 20;

	
	
	
			

		$fdata["strField"] = "member_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "member_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "personal";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
		
	$edata["LinkField"] = "member_id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "name";

				$edata["LookupWhere"] = "member_id = ':session.member_id'";


	
	$edata["LookupOrderBy"] = "";

	
	
	
	
				//dependent dropdowns @deprecated data ?
	$edata["DependentLookups"] = array();
	$edata["DependentLookups"][] = "group_member_id";

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["member_id"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "member_id";
//	group_id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "group_id";
	$fdata["GoodName"] = "group_id";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","group_id");
	$fdata["FieldType"] = 20;

	
	
	
			

		$fdata["strField"] = "group_id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "group_id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
				$edata["LookupType"] = 2;
	$edata["LookupTable"] = "group111";
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
			$edata["LookupUnique"] = true;

	$edata["LinkField"] = "group_id";
	$edata["LinkFieldType"] = 20;
	$edata["DisplayField"] = "group_name";

				$edata["LookupWhere"] = "group_product.`order_type` = 1 OR (group_member.valid = 1 AND group_member.member_id = ':session.member_id')";


	
	$edata["LookupOrderBy"] = "";

	
	
	
	

	
	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["group_id"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "group_id";
//	order_date
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "order_date";
	$fdata["GoodName"] = "order_date";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","order_date");
	$fdata["FieldType"] = 135;

	
	
	
			

		$fdata["strField"] = "order_date";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "order_date";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

		$edata["ShowTime"] = true;

		$edata["weekdayMessage"] = array("message" => "Invalid week day", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 2;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["order_date"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "order_date";
//	valid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "valid";
	$fdata["GoodName"] = "valid";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","valid");
	$fdata["FieldType"] = 129;

	
	
	
			

		$fdata["strField"] = "valid";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "valid";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["valid"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "valid";
//	total
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "total";
	$fdata["GoodName"] = "total";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","total");
	$fdata["FieldType"] = 5;

	
	
	
			

		$fdata["strField"] = "total";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "total";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["total"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "total";
//	currency
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "currency";
	$fdata["GoodName"] = "currency";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","currency");
	$fdata["FieldType"] = 200;

	
	
	
			

		$fdata["strField"] = "currency";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "currency";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
		$edata["LookupType"] = 0;
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
	
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "IDR";
	$edata["LookupValues"][] = "USD";

	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["currency"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "currency";
//	review_member
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "review_member";
	$fdata["GoodName"] = "review_member";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","review_member");
	$fdata["FieldType"] = 201;

	
	
	
			

		$fdata["strField"] = "review_member";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "review_member";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text area");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 0;

	
	
	
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;

	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

		$edata["CreateThumbnail"] = true;
	$edata["StrThumbnail"] = "th";
			$edata["ThumbnailSize"] = 600;

			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["review_member"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "review_member";
//	rating_member
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "rating_member";
	$fdata["GoodName"] = "rating_member";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","rating_member");
	$fdata["FieldType"] = 16;

	
	
	
			

		$fdata["strField"] = "rating_member";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "rating_member";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["rating_member"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "rating_member";
//	payment_status
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "payment_status";
	$fdata["GoodName"] = "payment_status";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","payment_status");
	$fdata["FieldType"] = 129;

	
	
	
			

		$fdata["strField"] = "payment_status";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "payment_status";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Lookup wizard");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	

// Begin Lookup settings
		$edata["LookupType"] = 0;
			$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;

	
	
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "paid";
	$edata["LookupValues"][] = "not_paid";

	
		$edata["SelectSize"] = 1;

// End Lookup Settings


	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["payment_status"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "payment_status";
//	money_received
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 12;
	$fdata["strName"] = "money_received";
	$fdata["GoodName"] = "money_received";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","money_received");
	$fdata["FieldType"] = 5;

	
	
	
			

		$fdata["strField"] = "money_received";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "money_received";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["money_received"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "money_received";
//	change_money
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 13;
	$fdata["strName"] = "change_money";
	$fdata["GoodName"] = "change_money";
	$fdata["ownerTable"] = "group_member_order";
	$fdata["Label"] = GetFieldLabel("group_member_order","change_money");
	$fdata["FieldType"] = 5;

	
	
	
			

		$fdata["strField"] = "change_money";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "change_money";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Number");

	
	
	
	
	
	
		$vdata["DecimalDigits"] = 0;

	
	
	
	
		
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypes"] = ".+$";
		$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
							
	
	//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdatagroup_member_order["change_money"] = $fdata;
		$tdatagroup_member_order[".searchableFields"][] = "change_money";


$tables_data["group_member_order"]=&$tdatagroup_member_order;
$field_labels["group_member_order"] = &$fieldLabelsgroup_member_order;
$fieldToolTips["group_member_order"] = &$fieldToolTipsgroup_member_order;
$placeHolders["group_member_order"] = &$placeHoldersgroup_member_order;
$page_titles["group_member_order"] = &$pageTitlesgroup_member_order;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["group_member_order"] = array();
//	group_member_order_detail
	
	

		$dIndex = 0;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="group_member_order_detail";
		$detailsParam["dOriginalTable"] = "group_member_order_detail";



		
		$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "group_member_order_detail";
	$detailsParam["dCaptionTable"] = GetTableCaption("group_member_order_detail");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["group_member_order"][$dIndex] = $detailsParam;

	
		$detailsTablesData["group_member_order"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["group_member_order"][$dIndex]["masterKeys"][]="group_member_order";

				$detailsTablesData["group_member_order"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["group_member_order"][$dIndex]["detailKeys"][]="group_member_order_id";
//	update_order_progess
	
	

		$dIndex = 1;
	$detailsParam = array();
	$detailsParam["dDataSourceTable"]="update_order_progess";
		$detailsParam["dOriginalTable"] = "group_member_order_detail";



		
		$detailsParam["dType"]=PAGE_LIST;
	$detailsParam["dShortTable"] = "update_order_progess";
	$detailsParam["dCaptionTable"] = GetTableCaption("update_order_progess");
	$detailsParam["masterKeys"] =array();
	$detailsParam["detailKeys"] =array();


		
	$detailsTablesData["group_member_order"][$dIndex] = $detailsParam;

	
		$detailsTablesData["group_member_order"][$dIndex]["masterKeys"] = array();

	$detailsTablesData["group_member_order"][$dIndex]["masterKeys"][]="group_member_order";

				$detailsTablesData["group_member_order"][$dIndex]["detailKeys"] = array();

	$detailsTablesData["group_member_order"][$dIndex]["detailKeys"][]="group_member_order_id";

// tables which are master tables for current table (detail)
$masterTablesData["group_member_order"] = array();



	
				$strOriginalDetailsTable="group";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="group";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "group";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["group_member_order"][0] = $masterParams;
				$masterTablesData["group_member_order"][0]["masterKeys"] = array();
	$masterTablesData["group_member_order"][0]["masterKeys"][]="group_id";
				$masterTablesData["group_member_order"][0]["detailKeys"] = array();
	$masterTablesData["group_member_order"][0]["detailKeys"][]="group_id";
		
	
				$strOriginalDetailsTable="personal";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="personal";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "personal";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["group_member_order"][1] = $masterParams;
				$masterTablesData["group_member_order"][1]["masterKeys"] = array();
	$masterTablesData["group_member_order"][1]["masterKeys"][]="member_id";
				$masterTablesData["group_member_order"][1]["detailKeys"] = array();
	$masterTablesData["group_member_order"][1]["detailKeys"][]="member_id";
		
	
				$strOriginalDetailsTable="group_member";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="group_member";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "group_member";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["group_member_order"][2] = $masterParams;
				$masterTablesData["group_member_order"][2]["masterKeys"] = array();
	$masterTablesData["group_member_order"][2]["masterKeys"][]="group_member_id";
				$masterTablesData["group_member_order"][2]["detailKeys"] = array();
	$masterTablesData["group_member_order"][2]["detailKeys"][]="group_member_id";
		
	
				$strOriginalDetailsTable="group";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="your_group";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "your_group";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["group_member_order"][3] = $masterParams;
				$masterTablesData["group_member_order"][3]["masterKeys"] = array();
	$masterTablesData["group_member_order"][3]["masterKeys"][]="group_id";
				$masterTablesData["group_member_order"][3]["detailKeys"] = array();
	$masterTablesData["group_member_order"][3]["detailKeys"][]="group_id";
		
	
				$strOriginalDetailsTable="group";
	$masterParams = array();
	$masterParams["mDataSourceTable"]="new_group_request";
	$masterParams["mOriginalTable"]= $strOriginalDetailsTable;
	$masterParams["mShortTable"]= "new_group_request";
	$masterParams["masterKeys"]= array();
	$masterParams["detailKeys"]= array();

	$masterParams["type"] = PAGE_LIST;
					$masterTablesData["group_member_order"][4] = $masterParams;
				$masterTablesData["group_member_order"][4]["masterKeys"] = array();
	$masterTablesData["group_member_order"][4]["masterKeys"][]="group_id";
				$masterTablesData["group_member_order"][4]["detailKeys"] = array();
	$masterTablesData["group_member_order"][4]["detailKeys"][]="group_id";
		
// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_group_member_order()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "group_member_order,  	group_member_id,  	member_id,  	group_id,  	order_date,  	valid,  	total,  	currency,  	review_member,  	rating_member,  	payment_status,  	money_received,  	change_money";
$proto0["m_strFrom"] = "FROM group_member_order";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "group_member_order",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto6["m_sql"] = "group_member_order";
$proto6["m_srcTableName"] = "group_member_order";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "group_member_id",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto8["m_sql"] = "group_member_id";
$proto8["m_srcTableName"] = "group_member_order";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "member_id",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto10["m_sql"] = "member_id";
$proto10["m_srcTableName"] = "group_member_order";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "group_id",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto12["m_sql"] = "group_id";
$proto12["m_srcTableName"] = "group_member_order";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "order_date",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto14["m_sql"] = "order_date";
$proto14["m_srcTableName"] = "group_member_order";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "valid",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto16["m_sql"] = "valid";
$proto16["m_srcTableName"] = "group_member_order";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "total",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto18["m_sql"] = "total";
$proto18["m_srcTableName"] = "group_member_order";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "currency",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto20["m_sql"] = "currency";
$proto20["m_srcTableName"] = "group_member_order";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
						$proto22=array();
			$obj = new SQLField(array(
	"m_strName" => "review_member",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto22["m_sql"] = "review_member";
$proto22["m_srcTableName"] = "group_member_order";
$proto22["m_expr"]=$obj;
$proto22["m_alias"] = "";
$obj = new SQLFieldListItem($proto22);

$proto0["m_fieldlist"][]=$obj;
						$proto24=array();
			$obj = new SQLField(array(
	"m_strName" => "rating_member",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto24["m_sql"] = "rating_member";
$proto24["m_srcTableName"] = "group_member_order";
$proto24["m_expr"]=$obj;
$proto24["m_alias"] = "";
$obj = new SQLFieldListItem($proto24);

$proto0["m_fieldlist"][]=$obj;
						$proto26=array();
			$obj = new SQLField(array(
	"m_strName" => "payment_status",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto26["m_sql"] = "payment_status";
$proto26["m_srcTableName"] = "group_member_order";
$proto26["m_expr"]=$obj;
$proto26["m_alias"] = "";
$obj = new SQLFieldListItem($proto26);

$proto0["m_fieldlist"][]=$obj;
						$proto28=array();
			$obj = new SQLField(array(
	"m_strName" => "money_received",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto28["m_sql"] = "money_received";
$proto28["m_srcTableName"] = "group_member_order";
$proto28["m_expr"]=$obj;
$proto28["m_alias"] = "";
$obj = new SQLFieldListItem($proto28);

$proto0["m_fieldlist"][]=$obj;
						$proto30=array();
			$obj = new SQLField(array(
	"m_strName" => "change_money",
	"m_strTable" => "group_member_order",
	"m_srcTableName" => "group_member_order"
));

$proto30["m_sql"] = "change_money";
$proto30["m_srcTableName"] = "group_member_order";
$proto30["m_expr"]=$obj;
$proto30["m_alias"] = "";
$obj = new SQLFieldListItem($proto30);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto32=array();
$proto32["m_link"] = "SQLL_MAIN";
			$proto33=array();
$proto33["m_strName"] = "group_member_order";
$proto33["m_srcTableName"] = "group_member_order";
$proto33["m_columns"] = array();
$proto33["m_columns"][] = "group_member_order";
$proto33["m_columns"][] = "group_member_id";
$proto33["m_columns"][] = "member_id";
$proto33["m_columns"][] = "group_id";
$proto33["m_columns"][] = "order_date";
$proto33["m_columns"][] = "valid";
$proto33["m_columns"][] = "total";
$proto33["m_columns"][] = "currency";
$proto33["m_columns"][] = "review_member";
$proto33["m_columns"][] = "rating_member";
$proto33["m_columns"][] = "payment_status";
$proto33["m_columns"][] = "money_received";
$proto33["m_columns"][] = "change_money";
$obj = new SQLTable($proto33);

$proto32["m_table"] = $obj;
$proto32["m_sql"] = "group_member_order";
$proto32["m_alias"] = "";
$proto32["m_srcTableName"] = "group_member_order";
$proto34=array();
$proto34["m_sql"] = "";
$proto34["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto34["m_column"]=$obj;
$proto34["m_contained"] = array();
$proto34["m_strCase"] = "";
$proto34["m_havingmode"] = false;
$proto34["m_inBrackets"] = false;
$proto34["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto34);

$proto32["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto32);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="group_member_order";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_group_member_order = createSqlQuery_group_member_order();


	
		;

													

$tdatagroup_member_order[".sqlquery"] = $queryData_group_member_order;



include_once(getabspath("include/group_member_order_events.php"));
$tableEvents["group_member_order"] = new eventclass_group_member_order;
$tdatagroup_member_order[".hasEvents"] = true;

?>